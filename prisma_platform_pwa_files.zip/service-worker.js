// Prisma Marketing Platform — service worker
// Só funciona de verdade quando estes arquivos estão hospedados em https:// (ex.: GitHub Pages,
// Netlify, Vercel). Aberto direto do computador (file://), o navegador ignora o service worker
// por segurança — isso não é um bug desta plataforma.

const CACHE_NAME = 'prisma-marketing-platform-v1';
const APP_SHELL = [
  './prisma_marketing_platform.html',
  './manifest.json',
  './icon.svg',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => {});
          return response;
        })
        .catch(() => cached);
    })
  );
});
